<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbarsideleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => '<i class="fa fa-home "></i>'
		),
		
		array(
			'path' => 'user', 
			'label' => 'User', 
			'icon' => '<i class="fa fa-user "></i>'
		),
		
		array(
			'path' => 'data_komplain', 
			'label' => 'Data Komplain', 
			'icon' => '<i class="fa fa-comment "></i>'
		),
		
		array(
			'path' => 'role_permissions', 
			'label' => 'Role Permissions', 
			'icon' => ''
		),
		
		array(
			'path' => 'roles', 
			'label' => 'Roles', 
			'icon' => ''
		)
	);
		
	
	
			public static $media_komplain = array(
		array(
			"value" => "WHATSAPP", 
			"label" => "WHATSAPP", 
		),
		array(
			"value" => "FACEBOOK", 
			"label" => "FACEBOOK", 
		),
		array(
			"value" => "INSTAGRAM", 
			"label" => "INSTAGRAM", 
		),
		array(
			"value" => "TIKTOK", 
			"label" => "TIKTOK", 
		),
		array(
			"value" => "GOOGLE RIVIEW", 
			"label" => "GOOGLE RIVIEW", 
		),
		array(
			"value" => "APK GOFOOD", 
			"label" => "APK GOFOOD", 
		),
		array(
			"value" => "APK GRABFOOD", 
			"label" => "APK GRABFOOD", 
		),
		array(
			"value" => "APK SHOPEEFOOD", 
			"label" => "APK SHOPEEFOOD", 
		),);
		
			public static $nama_store = array(
		array(
			"value" => "LC TEGAL", 
			"label" => "LC TEGAL", 
		),
		array(
			"value" => "LC ANTAPANI", 
			"label" => "LC ANTAPANI", 
		),
		array(
			"value" => "LC BABAKAN SARI", 
			"label" => "LC BABAKAN SARI", 
		),
		array(
			"value" => "LC MARGAHAYU", 
			"label" => "LC MARGAHAYU", 
		),
		array(
			"value" => "LC BALEENDAH", 
			"label" => "LC BALEENDAH", 
		),
		array(
			"value" => "LC RANCAMANYAR", 
			"label" => "LC RANCAMANYAR", 
		),
		array(
			"value" => "LC AL FATHU", 
			"label" => "LC AL FATHU", 
		),
		array(
			"value" => "LC KATAPANG", 
			"label" => "LC KATAPANG", 
		),
		array(
			"value" => "LC GADING TUTUKA", 
			"label" => "LC GADING TUTUKA", 
		),
		array(
			"value" => "LC CILEUNYI", 
			"label" => "LC CILEUNYI", 
		),
		array(
			"value" => "LC CIWIDEY", 
			"label" => "LC CIWIDEY", 
		),
		array(
			"value" => "LC CIHAMPELAS CILILIN", 
			"label" => "LC CIHAMPELAS CILILIN", 
		),
		array(
			"value" => "LC BOJONGSOANG", 
			"label" => "LC BOJONGSOANG", 
		),
		array(
			"value" => "LC DERWATI", 
			"label" => "LC DERWATI", 
		),
		array(
			"value" => "LC SARIMANAH", 
			"label" => "LC SARIMANAH", 
		),
		array(
			"value" => "LC MARGAASIH", 
			"label" => "LC MARGAASIH", 
		),
		array(
			"value" => "LC CIWARUGA", 
			"label" => "LC CIWARUGA", 
		),
		array(
			"value" => "LC TUBAGUS ISMAIL", 
			"label" => "LC TUBAGUS ISMAIL", 
		),
		array(
			"value" => "LC GEGER KALONG", 
			"label" => "LC GEGER KALONG", 
		),
		array(
			"value" => "LC SUKAGALIH", 
			"label" => "LC SUKAGALIH", 
		),
		array(
			"value" => "LC PERMATA CIMAHI", 
			"label" => "LC PERMATA CIMAHI", 
		),
		array(
			"value" => "LC CIPASIR", 
			"label" => "LC CIPASIR", 
		),
		array(
			"value" => "LC PANDAN WANGI", 
			"label" => "LC PANDAN WANGI", 
		),
		array(
			"value" => "LC UJUNG BERUNG", 
			"label" => "LC UJUNG BERUNG", 
		),
		array(
			"value" => "LC CIMANGGU", 
			"label" => "LC CIMANGGU", 
		),
		array(
			"value" => "LC CIBINONG", 
			"label" => "LC CIBINONG", 
		),
		array(
			"value" => "LC PCI", 
			"label" => "LC PCI", 
		),
		array(
			"value" => "LC SERDANG", 
			"label" => "LC SERDANG", 
		),
		array(
			"value" => "LC TEMU PUTIH", 
			"label" => "LC TEMU PUTIH", 
		),
		array(
			"value" => "LC JOMBANG", 
			"label" => "LC JOMBANG", 
		),
		array(
			"value" => "LC WARNASARI", 
			"label" => "LC WARNASARI", 
		),
		array(
			"value" => "LC ANYER", 
			"label" => "LC ANYER", 
		),
		array(
			"value" => "LC BBS", 
			"label" => "LC BBS", 
		),
		array(
			"value" => "LC GROGOL", 
			"label" => "LC GROGOL", 
		),
		array(
			"value" => "LC BOJONEGARA", 
			"label" => "LC BOJONEGARA", 
		),
		array(
			"value" => "LC MERAK", 
			"label" => "LC MERAK", 
		),
		array(
			"value" => "LC TEGAL CABE", 
			"label" => "LC TEGAL CABE", 
		),
		array(
			"value" => "LC KRENCENG", 
			"label" => "LC KRENCENG", 
		),
		array(
			"value" => "LC SENEJA", 
			"label" => "LC SENEJA", 
		),
		array(
			"value" => "LC CIBEBER", 
			"label" => "LC CIBEBER", 
		),
		array(
			"value" => "LC KEBON DALEM", 
			"label" => "LC KEBON DALEM", 
		),
		array(
			"value" => "LC KALITIMBANG", 
			"label" => "LC KALITIMBANG", 
		),
		array(
			"value" => "LC LEBAK INDAH", 
			"label" => "LC LEBAK INDAH", 
		),
		array(
			"value" => "LC TCI CILEGON", 
			"label" => "LC TCI CILEGON", 
		),
		array(
			"value" => "LC GALUH MAS", 
			"label" => "LC GALUH MAS", 
		),
		array(
			"value" => "LC MEGA REGENCY CIKARANG", 
			"label" => "LC MEGA REGENCY CIKARANG", 
		),
		array(
			"value" => "LC GARDU TANJAK", 
			"label" => "LC GARDU TANJAK", 
		),
		array(
			"value" => "LC MAJASARI", 
			"label" => "LC MAJASARI", 
		),
		array(
			"value" => "LC BAROS", 
			"label" => "LC BAROS", 
		),
		array(
			"value" => "LC LABUAN", 
			"label" => "LC LABUAN", 
		),
		array(
			"value" => "LC MENES", 
			"label" => "LC MENES", 
		),
		array(
			"value" => "LC PANIMBANG", 
			"label" => "LC PANIMBANG", 
		),
		array(
			"value" => "LC SIMPANG SATRIA (PANAM)", 
			"label" => "LC SIMPANG SATRIA (PANAM)", 
		),
		array(
			"value" => "LC BUKIT BARISAN", 
			"label" => "LC BUKIT BARISAN", 
		),
		array(
			"value" => "LC RUMBAI", 
			"label" => "LC RUMBAI", 
		),
		array(
			"value" => "LC PEMUDA", 
			"label" => "LC PEMUDA", 
		),
		array(
			"value" => "LC MULTATULI", 
			"label" => "LC MULTATULI", 
		),
		array(
			"value" => "LC ONA SILIWANGI", 
			"label" => "LC ONA SILIWANGI", 
		),
		array(
			"value" => "LC WARUNG GUNUNG", 
			"label" => "LC WARUNG GUNUNG", 
		),
		array(
			"value" => "LC JUANDA", 
			"label" => "LC JUANDA", 
		),
		array(
			"value" => "LC KRAGILAN", 
			"label" => "LC KRAGILAN", 
		),
		array(
			"value" => "LC LEGOK", 
			"label" => "LC LEGOK", 
		),
		array(
			"value" => "LC CIKANDE", 
			"label" => "LC CIKANDE", 
		),
		array(
			"value" => "LC CIRACAS", 
			"label" => "LC CIRACAS", 
		),
		array(
			"value" => "LC KALIGANDU", 
			"label" => "LC KALIGANDU", 
		),
		array(
			"value" => "LC CIPOCOK", 
			"label" => "LC CIPOCOK", 
		),
		array(
			"value" => "LC PAKUPATAN", 
			"label" => "LC PAKUPATAN", 
		),
		array(
			"value" => "LC KRAMATWATU", 
			"label" => "LC KRAMATWATU", 
		),
		array(
			"value" => "LC KASEMEN", 
			"label" => "LC KASEMEN", 
		),
		array(
			"value" => "LC WARINGIN KURUNG", 
			"label" => "LC WARINGIN KURUNG", 
		),
		array(
			"value" => "LC PETIR", 
			"label" => "LC PETIR", 
		),
		array(
			"value" => "LC CIWARU", 
			"label" => "LC CIWARU", 
		),
		array(
			"value" => "LC CIRUAS", 
			"label" => "LC CIRUAS", 
		),
		array(
			"value" => "LC KELAPA DUA", 
			"label" => "LC KELAPA DUA", 
		),
		array(
			"value" => "LC LOPANG", 
			"label" => "LC LOPANG", 
		),
		array(
			"value" => "LC PIPITAN", 
			"label" => "LC PIPITAN", 
		),
		array(
			"value" => "LC BHAYANGKARA", 
			"label" => "LC BHAYANGKARA", 
		),
		array(
			"value" => "LC CIDAHU", 
			"label" => "LC CIDAHU", 
		),
		array(
			"value" => "LC PALABUHAN RATU", 
			"label" => "LC PALABUHAN RATU", 
		),
		array(
			"value" => "LC CARINGIN", 
			"label" => "LC CARINGIN", 
		),
		array(
			"value" => "LC CISOKA", 
			"label" => "LC CISOKA", 
		),
		array(
			"value" => "LC MUNJUL", 
			"label" => "LC MUNJUL", 
		),
		array(
			"value" => "LC CIMANUK", 
			"label" => "LC CIMANUK", 
		),
		array(
			"value" => "LC SIMPANG LIMA", 
			"label" => "LC SIMPANG LIMA", 
		),
		array(
			"value" => "LC CIKAJANG", 
			"label" => "LC CIKAJANG", 
		),
		array(
			"value" => "LC PERUMNAS", 
			"label" => "LC PERUMNAS", 
		),
		array(
			"value" => "LC BULAK LAUT", 
			"label" => "LC BULAK LAUT", 
		),
		array(
			"value" => "LC JATOS", 
			"label" => "LC JATOS", 
		),
		array(
			"value" => "LC INDIHIANG", 
			"label" => "LC INDIHIANG", 
		),
		array(
			"value" => "LC SILIWANGI", 
			"label" => "LC SILIWANGI", 
		),
		array(
			"value" => "LC SUDIRMAN", 
			"label" => "LC SUDIRMAN", 
		),
		array(
			"value" => "LC AHMAD YANI", 
			"label" => "LC AHMAD YANI", 
		),
		array(
			"value" => "LC CIBARAJA CIBATU", 
			"label" => "LC CIBARAJA CIBATU", 
		),
		array(
			"value" => "LC SINGAPARNA", 
			"label" => "LC SINGAPARNA", 
		),
		array(
			"value" => "OFC CIBATU", 
			"label" => "OFC CIBATU", 
		),
		array(
			"value" => "OFC LEGOK JABAR (CICALENGKA)", 
			"label" => "OFC LEGOK JABAR (CICALENGKA)", 
		),
		array(
			"value" => "OFC KONCARA", 
			"label" => "OFC KONCARA", 
		),
		array(
			"value" => "LC SUKAMENAK", 
			"label" => "LC SUKAMENAK", 
		),
		array(
			"value" => "LC ANGKREK", 
			"label" => "LC ANGKREK", 
		),
		array(
			"value" => "LC PERJUANGAN", 
			"label" => "LC PERJUANGAN", 
		),
		array(
			"value" => "LC BANTENG", 
			"label" => "LC BANTENG", 
		),
		array(
			"value" => "OFC CICURUG", 
			"label" => "OFC CICURUG", 
		),
		array(
			"value" => "LC CAGAR ALAM", 
			"label" => "LC CAGAR ALAM", 
		),
		array(
			"value" => "LC SUMBER", 
			"label" => "LC SUMBER", 
		),
		array(
			"value" => "LC MAJALENGKA", 
			"label" => "LC MAJALENGKA", 
		),);
		
			public static $no_hp_konsumen = array(
		array(
			"value" => "+62", 
			"label" => "+62", 
		),);
		
			public static $kategori_komplain = array(
		array(
			"value" => "QUALITAS PRODUK", 
			"label" => "QUALITAS PRODUK", 
		),
		array(
			"value" => "PRODUK TIDAK SESUAI", 
			"label" => "PRODUK TIDAK SESUAI", 
		),
		array(
			"value" => "PRODUK KOSONG", 
			"label" => "PRODUK KOSONG", 
		),
		array(
			"value" => "ITEM KURANG", 
			"label" => "ITEM KURANG", 
		),
		array(
			"value" => "ITEM SALAH", 
			"label" => "ITEM SALAH", 
		),
		array(
			"value" => "PELAYANAN", 
			"label" => "PELAYANAN", 
		),
		array(
			"value" => "PERALATAN / BULIDING", 
			"label" => "PERALATAN / BULIDING", 
		),);
		
			public static $status_komplain = array(
		array(
			"value" => "DONE KOMPLIMENTARY", 
			"label" => "DONE KOMPLIMENTARY", 
		),
		array(
			"value" => "DONE NON KOMPLIMENTARY", 
			"label" => "DONE NON KOMPLIMENTARY", 
		),
		array(
			"value" => "CUSTOMER NO RESPON", 
			"label" => "CUSTOMER NO RESPON", 
		),
		array(
			"value" => "CUSTOMER FEEDBACK", 
			"label" => "CUSTOMER FEEDBACK", 
		),);
		
			public static $pic_handle = array(
		array(
			"value" => "NANA", 
			"label" => "NANA", 
		),
		array(
			"value" => "WANWAN", 
			"label" => "WANWAN", 
		),
		array(
			"value" => "MUHTAR", 
			"label" => "MUHTAR", 
		),
		array(
			"value" => "IWAN", 
			"label" => "IWAN", 
		),
		array(
			"value" => "MEIRSYAL", 
			"label" => "MEIRSYAL", 
		),
		array(
			"value" => "BANI", 
			"label" => "BANI", 
		),);
		
}